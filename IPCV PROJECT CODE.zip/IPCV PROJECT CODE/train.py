import torch
from torch.utils.data import DataLoader
from models.deanetpp import DEANetPP
from dataset import LOLDataset
from losses import VGGLoss, smoothing_loss
import argparse, os

def train(args):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    ds = LOLDataset(args.low_dir, args.high_dir)
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=True, num_workers=4)
    model = DEANetPP().to(device)
    vgg = VGGLoss(device=device)
    opt = torch.optim.Adam(model.parameters(), lr=1e-4)
    os.makedirs(args.save_dir, exist_ok=True)
    for epoch in range(args.epochs):
        total=0
        for low, high in dl:
            low, high = low.to(device), high.to(device)
            opt.zero_grad()
            out, R, L, R_e, L_e = model(low)
            loss_rec = torch.nn.functional.l1_loss(out, high)
            loss_vgg = vgg(out, high)
            loss_s = smoothing_loss(L)
            loss = loss_rec + 0.1*loss_vgg + 0.01*loss_s
            loss.backward()
            opt.step()
            total += loss.item()
        avg = total / len(dl)
        print(f"Epoch {epoch+1}/{args.epochs}  loss={avg:.4f}")
        torch.save(model.state_dict(), os.path.join(args.save_dir, f'checkpoint_epoch{epoch+1}.pth'))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--low_dir', required=True)
    parser.add_argument('--high_dir', required=True)
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--batch_size', type=int, default=4)
    parser.add_argument('--save_dir', default='checkpoints')
    args=parser.parse_args()
    train(args)
