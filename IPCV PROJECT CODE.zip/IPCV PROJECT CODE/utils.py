import numpy as np
from skimage.metrics import peak_signal_noise_ratio as compare_psnr
from skimage.metrics import structural_similarity as compare_ssim

def psnr_np(a,b):
    a = np.clip(a*255,0,255).astype('uint8')
    b = np.clip(b*255,0,255).astype('uint8')
    return compare_psnr(a,b, data_range=255)

def ssim_np(a,b):
    a = np.clip(a*255,0,255).astype('uint8')
    b = np.clip(b*255,0,255).astype('uint8')
    return compare_ssim(a,b, multichannel=True, data_range=255)
