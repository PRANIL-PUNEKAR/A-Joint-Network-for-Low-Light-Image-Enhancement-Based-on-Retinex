import torch
import torch.nn as nn

class ChannelAttention(nn.Module):
    def __init__(self, in_ch, ratio=8):
        super().__init__()
        self.avg = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(in_ch, max(in_ch//ratio,1), 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(max(in_ch//ratio,1), in_ch, 1),
            nn.Sigmoid()
        )
    def forward(self, x):
        w = self.avg(x)
        w = self.fc(w)
        return x * w
