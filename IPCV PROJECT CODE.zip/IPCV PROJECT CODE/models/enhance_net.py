import torch
import torch.nn as nn
from .attention import ChannelAttention

class DenseBlock(nn.Module):
    def __init__(self, in_ch, growth=16):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_ch, growth, 3, padding=1),
            nn.ReLU(inplace=True)
        )
    def forward(self, x):
        out = self.conv(x)
        return torch.cat([x, out], dim=1)

class EnhanceNet(nn.Module):
    def __init__(self, base=32):
        super().__init__()
        self.entry = nn.Conv2d(3, base, 3, padding=1)
        self.db1 = DenseBlock(base, 16)
        self.db2 = DenseBlock(base+16, 16)
        self.ca = ChannelAttention(base+32)
        self.res = nn.Conv2d(base+32, 3, 3, padding=1)
    def forward(self, x):
        f = self.entry(x)
        f = self.db1(f)
        f = self.db2(f)
        f = self.ca(f)
        out = torch.sigmoid(self.res(f))
        return out
