import torch
import torch.nn as nn
from .attention import ChannelAttention

class ResBlock(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch, ch, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(ch, ch, 3, padding=1),
        )
    def forward(self, x): return x + self.conv(x)

class AdjustNet(nn.Module):
    def __init__(self, base=32):
        super().__init__()
        self.enc = nn.Conv2d(6, base, 3, padding=1)
        self.res = ResBlock(base)
        self.ca = ChannelAttention(base)
        self.dec = nn.Conv2d(base, 3, 3, padding=1)
    def forward(self, x):
        f = self.enc(x)
        f = self.res(f)
        f = self.ca(f)
        out = torch.sigmoid(self.dec(f))
        return out
