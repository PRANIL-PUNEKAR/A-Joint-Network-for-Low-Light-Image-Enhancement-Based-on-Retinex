import torch
import torch.nn as nn
from .decompose_net import DecomposeNet
from .enhance_net import EnhanceNet
from .adjust_net import AdjustNet

class DEANetPP(nn.Module):
    def __init__(self):
        super().__init__()
        self.decomp = DecomposeNet()
        self.enh = EnhanceNet()
        self.adjust = AdjustNet()
    def forward(self, x):
        R, L = self.decomp(x)
        L3 = L.repeat(1,3,1,1)
        R_enh = self.enh(R)
        L_enh = self.enh(L3)
        cat = torch.cat([R_enh, L_enh], dim=1)
        out = self.adjust(cat)
        return out, R, L, R_enh, L_enh
