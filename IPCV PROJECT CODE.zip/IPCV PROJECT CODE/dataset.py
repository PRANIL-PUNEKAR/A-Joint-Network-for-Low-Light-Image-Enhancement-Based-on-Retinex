import os
from PIL import Image
from torch.utils.data import Dataset
import torchvision.transforms as T

transform = T.Compose([T.Resize((400,600)), T.ToTensor()])

class LOLDataset(Dataset):
    def __init__(self, low_dir, high_dir):
        self.low = sorted([os.path.join(low_dir,f) for f in os.listdir(low_dir) if f.lower().endswith(('.png','.jpg'))])
        self.high = sorted([os.path.join(high_dir,f) for f in os.listdir(high_dir) if f.lower().endswith(('.png','.jpg'))])
        assert len(self.low)==len(self.high), "low/high count mismatch"
    def __len__(self): return len(self.low)
    def __getitem__(self, idx):
        l = Image.open(self.low[idx]).convert('RGB')
        h = Image.open(self.high[idx]).convert('RGB')
        return transform(l), transform(h)
