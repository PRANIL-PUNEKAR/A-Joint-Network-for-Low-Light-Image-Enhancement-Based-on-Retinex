import torch
import torch.nn as nn
from torchvision import models

l1 = nn.L1Loss()

class VGGLoss(nn.Module):
    def __init__(self, device='cpu'):
        super().__init__()
        vgg = models.vgg19(pretrained=True).features.eval()
        for p in vgg.parameters(): p.requires_grad=False
        self.vgg = vgg.to(device)
        self.layers = [2,7,12,21]
    def forward(self, x, y):
        feats_x = self.get_features(x)
        feats_y = self.get_features(y)
        loss = 0
        for fx, fy in zip(feats_x, feats_y):
            loss += torch.mean(torch.abs(fx - fy))
        return loss
    def get_features(self, img):
        out=[]
        x=img
        for i,layer in enumerate(self.vgg):
            x = layer(x)
            if i in self.layers:
                out.append(x)
        return out

def smoothing_loss(L):
    dh = torch.mean(torch.abs(L[:,:,1:,:] - L[:,:,:-1,:]))
    dw = torch.mean(torch.abs(L[:,:,:,1:] - L[:,:,:,:-1]))
    return dh + dw
