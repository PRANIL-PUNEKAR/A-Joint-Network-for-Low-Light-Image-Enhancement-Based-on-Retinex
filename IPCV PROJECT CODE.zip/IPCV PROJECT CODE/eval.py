import torch
from PIL import Image
import torchvision.transforms as T
from models.deanetpp import DEANetPP
import argparse, os

to_tensor = T.ToTensor()
to_pil = T.ToPILImage()

def enhance_image(checkpoint, input_path, output_path):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = DEANetPP().to(device)
    model.load_state_dict(torch.load(checkpoint, map_location=device))
    model.eval()
    img = Image.open(input_path).convert('RGB')
    x = to_tensor(img).unsqueeze(0).to(device)
    with torch.no_grad():
        out, *_ = model(x)
    out_img = out[0].cpu()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    to_pil(out_img).save(output_path)
    print('Saved', output_path)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--checkpoint', required=True)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args=parser.parse_args()
    enhance_image(args.checkpoint, args.input, args.output)
