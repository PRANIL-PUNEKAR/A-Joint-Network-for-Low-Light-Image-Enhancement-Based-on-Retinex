print('losses placeholder')
